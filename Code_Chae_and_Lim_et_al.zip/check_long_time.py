"""
code  written by junghun Chae

If you have any question, please email to the following address.
wjdgnswkd612@gmail.com

Readme
This is a sample codes to check a long-period behavior of a system. 
'U' refers 'u_bar'.
'V' refers 'v_bar'.
"""
#-*-coding: utf-8 -*-
from scipy.integrate import solve_ivp 
import matplotlib.pyplot as plt 
import numpy as np

def X(t):
    ### --- total protein concentration example
    # input : t - time [hr]
    # output : total protein conecentration.
    # For simplicity cosine function is used.  
    return  (- np.cos( t * np.pi / 12 ) + 3) 
#

def equation_Full(y, t, para, Xprof):
    ### --- ODE systems.
    # input : 
    # y     - array of current elements 
    # t     - time 
    # para  - array of parameters 
    # Xprof - function that takes time and return total protein concentration 
    # ouput : 
    # dxvardt   - array of time derivatives of each element at given time t  

    dxvardt = np.zeros(4)

    a0 = para[0]
    a1 = para[1]
    a2 = para[2]
    b0 = para[3]
    b1 = para[4]
    q = para[5]
    s = para[6]
    r0 = para[7]
    U = para[8]
    V = para[9]

    substrate_sum=0
    for i in range(4):
        substrate_sum = substrate_sum + y[i]
    freex = Xprof(t) - substrate_sum

    xeo = y[0]; xeub = y[1]; xoub = y[2]; xhub = y[3]

    u = U - xeo - xeub
    v = V - xhub

    dxvardt[0] = a0*u*freex - a1*xeo - q*xeo

    dxvardt[1] = q*xeo + a0*u*xoub - a2*xeub - r0*xeub

    dxvardt[2] = a2*xeub - a0*u*xoub -b0*v*xoub + b1*xhub - r0*xoub

    dxvardt[3] = b0*v*xoub - b1*xhub - s*xhub - r0*xhub

    return dxvardt
# 

class Result:
    ### --- container for results 
    def __init__(self):
        self.feasible = True 
        self.t = 0 
        self.x0 = 0
        self.xe0 = 0 
        self.xeub = 0
        self.x0ub = 0 
        self.xhub = 0
        self.simulation_length = 0
    #
#

def solve_ode(para = False):
    ### --- main function 
    # y0    - initial condition
    # dt    - time difference between time steps 
    # t_eval    - time points array to get ODE solutions 
    y0 = [0, 0, 0, 0]
    dt = 0.05
    simulation_length = 5
    t_eval = [i * dt for i in range( int(24 * simulation_length/dt) + 1 )]

    # --- parameter array 
    if not para:
        para = [0 for i in range(10)]
        a0 = para[0] = 10
        a1 = para[1] = 10
        a2 = para[2] = 10
        b0 = para[3] = 10
        b1 = para[4] = 10
        q = para[5] = 10
        s = para[6] = 10
        r0 = para[7] = 0.5
        U = para[8] = 0.5
        V = para[9] = 0.5
    else:
        a0 = para[0] 
        a1 = para[1] 
        a2 = para[2] 
        b0 = para[3] 
        b1 = para[4] 
        q = para[5] 
        s = para[6] 
        r0 = para[7] 
        U = para[8] 
        V = para[9] 
    #

    xnew = solve_ivp(fun = lambda  t,y: equation_Full(y, t,  para, X),\
                    y0 = y0, t_eval = t_eval, t_span = [0, t_eval[-1]], method = "RK45")

    t = xnew.t 
    xe0  = xnew.y[0]
    xeub = xnew.y[1]
    x0ub = xnew.y[2]
    xhub = xnew.y[3]

    # --- total X array 
    X_total = [] 
    for i in t:
        X_total.append(X(i))
    #
    X_total = np.array(X_total)

    # --- the concentration of free proteins without any modifications
    x0 = X_total - xe0 - xeub - x0ub - xhub

    # --- the concentration of ubiquitin ligases, not binding to their substrate proteins
    u = U - xe0 - xeub

    # --- the concentration of deubiquitinating enzymes, not binding to their substrate proteins
    v = V - xhub 

    # --- protein synthesis rate 
    # for 2nd order numerical derivatives, first and last 2 elements are disregarded. 
    g = []
    g.append(0.1)
    g.append(0.1)
    for i in range(2, len(t)-2):
        dt = t[i+1]-t[i]
        g.append(( -x0[i+2] + 8 * x0[i+1] - 8 * x0[i-1] \
                    + x0[i-2] ) / 12 / dt + a0 * u[i] * x0[i] - a1 * xe0[i] - s * xhub[i])
    #
    g.append(g[-1])
    g.append(g[-1])
    g = np.array(g)

    # --- Test physical constraints. 
    feasible = True 

    if min(x0) < 0 : 
        feasible = False 
    #
    if min(xe0) < 0 : 
        feasible = False 
    #
    if min(xeub) < 0 : 
        feasible = False 
    #
    if min(x0ub) < 0 : 
        feasible = False 
    #
    if min(xhub) < 0 : 
        feasible = False
    #
    if min(u) < 0 : 
        feasible = False 
    #
    if min(v) < 0 : 
        feasible = False 
    #
    if min(g) < 0 : 
        feasible = False 
    #

    res = Result()

    res.feasible = feasible

    if not feasible:
        return res
    else : 
        res.x0      = x0
        res.x0ub    = x0ub
        res.xe0     = xe0
        res.xeub    = xeub
        res.xhub    = xhub
        res.t       = t
        res.simulation_length  = simulation_length

        return res 
    #
#

def draw(res,  num_period = 3, pop = True, save_dir = False):
    ### --- draw time series of elements 
    # res           - Result container object
    # length        - total simulation length
    # num_period    - number of period to show (from the end of simulation)
    # pop           - whether to pop up the graph 
    # save_dir      - if False, do not save the graph. To save graph, directory including file name should be given
    # the file name should end with ".png"
    if not res.feasible :
        print("infeasible solution given")
        return 0
    length = res.simulation_length
    index_len = len(res.t)
    index_len_per_period = int(index_len / length)

    plt.plot(res.t[-index_len_per_period * num_period :], res.x0[-index_len_per_period * num_period :], label = "x0")
    plt.plot(res.t[-index_len_per_period * num_period :], res.xe0[-index_len_per_period * num_period :], label = "xe0")
    plt.plot(res.t[-index_len_per_period * num_period :], res.xeub[-index_len_per_period * num_period :], label = "xeub")
    plt.plot(res.t[-index_len_per_period * num_period :], res.x0ub[-index_len_per_period * num_period :], label = "x0ub")
    plt.plot(res.t[-index_len_per_period * num_period :], res.xhub[-index_len_per_period * num_period :], label = "xhub")
    plt.legend(loc = 'right')
    plt.grid()
    plt.xlabel("time [h]")
    plt.ylabel("concentration [nM]")
    if isinstance(save_dir, str):
        plt.savefig(save_dir)
    #
    if pop:
        plt.show()
    #
    plt.clf()
    plt.cla()
    plt.close("all")
#

if __name__ == "__main__":
    ### --- main script
    res = solve_ode()
    draw(res, num_period = 10, pop = True, save_dir = False)
#