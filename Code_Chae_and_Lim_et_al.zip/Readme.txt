Python codes for "Backward Simulation for Inferring Hidden 
Biomolecular Kinetic Profiles".

File name : check_debug.py, check_initial_conditions_sensitivity.py, 
check_long_time.py, check_physical_constraints.py 

### --- system requirements 
- Windows, Linux or macOS 
- Python 3.7 or later 
- The following Python packages are required:
 scipy, matplotlib, numpy, random

### --- General information 
The protein degradation model from Lim et al. (2021) when 
the protein abundance profile x(t) is maintained. 
These codes solve the protein degradation model when 
phosphorylation is not involved. 

"check_initial_conditions_sensitivity.py"       : This code provides an example of 
checking how substrate profiles are sensitive to initial conditions in "BS of a 
circadian protein degradation model", step4-a. The code shows simulation 
results with 10 different initial conditions with same parameters. This example 
shows the solutions reach same trajectories eventually. 

"check_long_time.py"                            : This code provides an example of 
checking how substrate profiles behave in long periods in "BS of a circadian 
protein degradation model", step4-b. The simulation results show the solution 
eventually reaches a sustained oscillation. 

"check_physical_constraints.py"                 : This code provides an example of 
checking whether the solution satisfies the implicit constraints in "BS of a 
circadian protein degradation model", step4-c. The code shows whether the 
solution satisfies all the physical or biological constraints.  

"check_debug.py"                                : This code provides an example of 
debug process in "BS of a circadian protein degradation model", step4-d. The 
code shows two simulation results. One with condition that v_bar is set to zero.
Another one with conditions that a0, b0, u_bar, v_bar are set relatively high,
 and a2, b1 are set relatively low.
 
### --- Input & Output 
There is no input file required.
There is no output file made by these codes. 

"check_debug.py"
"check_initial_conditions_sensitivity.py"
"check_long_time.py"
Executing the above codes will show substrates profiles.  

"check_physical_constraints.py"
Executing the above codes will show whether the solution satisfies 
the implicit constraints. 

*** Contact information
This code was written by Junghun Chae.
If you have any question, please contact to J. Chae by 
"wjdgnswkd612@gmail.com".

References 
Lim, R., Chae, J., Somers, D.E., Ghim, C.-M. and Kim, P.-J. (2021). 
Cost-effective circadian mechanism: rhythmic degradation of circadian proteins 
spontaneously emerges without rhythmic post-translational regulation. 
iScience 24, 102726.