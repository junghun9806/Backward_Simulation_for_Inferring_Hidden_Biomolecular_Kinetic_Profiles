Python codes for "Backward Simulation for Inferring Hidden 
Biomolecular Kinetic Profiles".

File name : check_debug.py, check_initial_conditions_sensitivity.py, 
check_long_time.py, check_physical_constraints.py 

### --- system requirements 
- Windows, Linux or macOS 
- Python 3.7 or later 
- The following Python packages are required:
 scipy, matplotlib, numpy, random

### --- General information 
The protein degradation model from Lim et al. (2021) when 
the protein abundance profile x(t) is maintained. 
These codes solve the protein degradation model when 
phosphorylation is not involved. 
"check_debug.py"                                : This code provides an example of 
debug process. 
"check_initial_conditions_sensitivity.py"       : This code provides an example of 
checking how substrates profiles are sensitive to initial conditions. 
"check_long_time.py"                            : This code provides an example of 
checking how substrates profiles behaves in long periods. 
"check_physical_constraints.py"                 : This code provides an example of 
checking whether the solution satisfies the implicit constraints. 

### --- Input & Output 
There is no input file required.
There is no output file made by these codes. 

"check_debug.py"
"check_initial_conditions_sensitivity.py"
"check_long_time.py"
Executing the above codes will show substrates profiles.  

"check_physical_constraints.py"
Executing the above codes will show whether the solution satisfies 
the implicit constraints. 

*** Contact information
This code was written by Junghun Chae.
If you have any question, please contact to J. Chae by 
"wjdgnswkd612@gmail.com".

References 
Lim, R., Chae, J., Somers, D.E., Ghim, C.-M. and Kim, P.-J. (2021). 
Cost-effective circadian mechanism: rhythmic degradation of circadian proteins 
spontaneously emerges without rhythmic post-translational regulation. 
iScience 24, 102726.