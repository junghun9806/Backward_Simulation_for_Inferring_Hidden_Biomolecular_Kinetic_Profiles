"""
code  written by junghun Chae

If you have any questions, please email to the following address.
wjdgnswkd612@gmail.com

Readme
This is a sample codes to check how system behaves depending on their initial conditions. 
'U' refers 'u_bar'.
'V' refers 'v_bar'.
"""
#-*-coding: utf-8 -*-
from scipy.integrate import solve_ivp 
import matplotlib.pyplot as plt 
import numpy as np
import random as rd

def X(t):
    ### --- total protein concentration example
    # input : t - time [hr]
    # output : the total protein conecentration.
    # For simplicity a cosine function is used.  
    return  - np.cos( t * np.pi / 12 ) + 2 
#

def equation_Full(y, t, para, Xprof):
    ### --- ODE systems.
    # input : 
    # y     - an array of current elements 
    # t     - time 
    # para  - an array of parameters 
    # Xprof - a function that takes time and return total protein concentration 
    # ouput : 
    # dxvardt   - an array of time derivatives of each element at given time t  

    dxvardt = np.zeros(4)

    a0 = para[0]
    a1 = para[1]
    a2 = para[2]
    b0 = para[3]
    b1 = para[4]
    q = para[5]
    s = para[6]
    r0 = para[7]
    U = para[8]
    V = para[9]

    substrate_sum=0
    for i in range(4):
        substrate_sum = substrate_sum + y[i]
    freex = Xprof(t) - substrate_sum

    xeo = y[0]; xeub = y[1]; xoub = y[2]; xhub = y[3]

    u = U - xeo - xeub
    v = V - xhub

    dxvardt[0] = a0*u*freex - a1*xeo - q*xeo

    dxvardt[1] = q*xeo + a0*u*xoub - a2*xeub - r0*xeub

    dxvardt[2] = a2*xeub - a0*u*xoub -b0*v*xoub + b1*xhub - r0*xoub

    dxvardt[3] = b0*v*xoub - b1*xhub - s*xhub - r0*xhub

    return dxvardt
# 

class Result:
    ### --- a container for results 
    def __init__(self):
        self.feasible = True 
        self.t = 0 
        self.x0 = 0
        self.xe0 = 0 
        self.xeub = 0
        self.x0ub = 0 
        self.xhub = 0
        self.g = 0
        self.simulation_length = 0
    #
#

def solve_ode(para = False, y0 = False):
    ### --- main function 
    # y0        - the initial condition
    # dt        - the time difference between time steps 
    # t_eval    - the time points array to get ODE solutions 
    # para      - the list container for parameters
    dt = 0.05
    simulation_length = 10
    t_eval = [i * dt for i in range( int(24 * simulation_length/dt) + 1 )]

    if not y0 : 
        y0 = [0, 0, 0, 0]

    # --- the parameter array 
    if not para:
        para = [0 for i in range(10)]
        a0 = para[0] = 10
        a1 = para[1] = 1
        a2 = para[2] = 1
        b0 = para[3] = 10
        b1 = para[4] = 1
        q = para[5] = 1
        s = para[6] = 1
        r0 = para[7] = 1
        U = para[8] = 1
        V = para[9] = 1
    else:
        a0 = para[0] 
        a1 = para[1] 
        a2 = para[2] 
        b0 = para[3] 
        b1 = para[4] 
        q = para[5] 
        s = para[6] 
        r0 = para[7] 
        U = para[8] 
        V = para[9] 
    #

    xnew = solve_ivp(fun = lambda  t,y: equation_Full(y, t,  para, X),\
                    y0 = y0, t_eval = t_eval, t_span = [0, t_eval[-1]], method = "LSODA", rtol=1e-5)
                    

    t = xnew.t 
    xe0  = xnew.y[0]
    xeub = xnew.y[1]
    x0ub = xnew.y[2]
    xhub = xnew.y[3]

    # --- the total X array 
    X_total = [] 
    for i in t:
        X_total.append(X(i))
    #
    X_total = np.array(X_total)

    # --- the concentration of the free protein without any modifications
    x0 = X_total - xe0 - xeub - x0ub - xhub

    # --- the concentration of the ubiquitin ligase, not binding to their substrate protein
    u = U - xe0 - xeub

    # --- the concentration of the deubiquitinating enzyme, not binding to their substrate protein
    v = V - xhub 

    # --- protein synthesis rate 
    # for 2nd order numerical derivatives, first and last 2 elements (total 4 elements) are disregarded. 
    g = []
    g.append(0.1)
    g.append(0.1)
    for i in range(2, len(t)-2):
        dt = t[i+1]-t[i]
        g.append(( -x0[i+2] + 8 * x0[i+1] - 8 * x0[i-1] \
                    + x0[i-2] ) / 12 / dt + a0 * u[i] * x0[i] - a1 * xe0[i] - s * xhub[i])
    #
    g.append(g[-1])
    g.append(g[-1])
    g = np.array(g)

    # --- Test physical constraints. 
    feasible = True 

    if min(x0) < 0 : 
        feasible = False 
    #
    if min(xe0) < 0 : 
        feasible = False 
    #
    if min(xeub) < 0 : 
        feasible = False 
    #
    if min(x0ub) < 0 : 
        feasible = False 
    #
    if min(xhub) < 0 : 
        feasible = False
    #
    if min(u) < 0 : 
        feasible = False 
    #
    if min(v) < 0 : 
        feasible = False 
    #
    if min(g) < 0 : 
        feasible = False 
    #

    res = Result()

    res.feasible = feasible

    if not feasible:
        return res
    else : 
        res.x0      = x0
        res.x0ub    = x0ub
        res.xe0     = xe0
        res.xeub    = xeub
        res.xhub    = xhub
        res.t       = t
        res.g       = g
        res.simulation_length  = simulation_length
        return res 
    #
#

def draw_different_intial(res_list, length = 10, num_period = 3, r0 = 1, pop = True, save_dir = False):
    ### --- draw time series of elements 
    # res           - the result container object
    # length        - the total simulation length
    # num_period    - the number of period to show (from the end of simulation)
    # pop           - whether to pop up the graph 
    # save_dir      - if the variable is set False, it does not save the graph. 
    # To save graph, a directory path including the file name should be given.
    # the file name should end with ".png"

    for res_idx, res in enumerate(res_list):
        if not res.feasible :
            continue
        index_len = len(res.t)
        index_len_per_period = int(index_len / length)

        plt.plot(res.t[ : index_len_per_period * num_period ], res.x0[ : index_len_per_period * num_period ], label = str(res_idx))
    plt.legend()
    plt.grid()
    plt.xlabel("time [h]")
    plt.ylabel("concentration [nM]")  
    if isinstance(save_dir, str):
        plt.savefig(save_dir.replace(".png", "_x0.png"))
    #
    if pop:
        plt.show()
    #
    plt.clf()
    plt.cla()
    plt.close("all")  

    for res_idx, res in enumerate(res_list):
        if not res.feasible :
            continue
        index_len = len(res.t)
        index_len_per_period = int(index_len / length)

        plt.plot(res.t[ : index_len_per_period * num_period ], res.xe0[ : index_len_per_period * num_period ], label = str(res_idx))
    plt.legend()
    plt.grid()
    plt.xlabel("time [h]")
    plt.ylabel("concentration [nM]")  
    if isinstance(save_dir, str):
        plt.savefig(save_dir.replace(".png", "_xe0.png"))
    #
    if pop:
        plt.show()
    #
    plt.clf()
    plt.cla()
    plt.close("all")  

    for res_idx, res in enumerate(res_list):
        if not res.feasible :
            continue
        index_len = len(res.t)
        index_len_per_period = int(index_len / length)

        plt.plot(res.t[ : index_len_per_period * num_period ], res.xeub[ : index_len_per_period * num_period ], label = str(res_idx))
    plt.legend()
    plt.grid()
    plt.xlabel("time [h]")
    plt.ylabel("concentration [nM]")  
    if isinstance(save_dir, str):
        plt.savefig(save_dir.replace(".png", "_xeub.png"))
    #
    if pop:
        plt.show()
    #
    plt.clf()
    plt.cla()
    plt.close("all")  

    for res_idx, res in enumerate(res_list):
        if not res.feasible :
            continue
        index_len = len(res.t)
        index_len_per_period = int(index_len / length)

        plt.plot(res.t[ : index_len_per_period * num_period ], res.xhub[ : index_len_per_period * num_period ], label = str(res_idx))
    plt.legend()
    plt.grid()
    plt.xlabel("time [h]")
    plt.ylabel("concentration [nM]")  
    if isinstance(save_dir, str):
        plt.savefig(save_dir.replace(".png", "_xhub.png"))
    #
    if pop:
        plt.show()
    #
    plt.clf()
    plt.cla()
    plt.close("all")  

    for res_idx, res in enumerate(res_list):
        if not res.feasible :
            continue
        index_len = len(res.t)
        index_len_per_period = int(index_len / length)

        plt.plot(res.t[ : index_len_per_period * num_period ], res.g[ : index_len_per_period * num_period ], label = str(res_idx))
    plt.legend()
    plt.grid()
    plt.xlabel("time [h]")
    plt.ylabel("protein synthesis rate [nM/h]")  
    if isinstance(save_dir, str):
        plt.savefig(save_dir.replace(".png", "_g.png"))
    #
    if pop:
        plt.show()
    #
    plt.clf()
    plt.cla()
    plt.close("all")  

    

    for res_idx, res in enumerate(res_list):
        if not res.feasible :
            continue
        index_len = len(res.t)
        index_len_per_period = int(index_len / length)
        rt = r0 * (res.xeub + res.x0ub + res.xhub ) / (res.x0 + res.xe0 + res.xeub + res.x0ub + res.xhub) 

        plt.plot(res.t[ : index_len_per_period * num_period ], rt[ : index_len_per_period * num_period ], label = str(res_idx))
    plt.legend()
    plt.grid()
    plt.xlabel("time [h]")
    plt.ylabel("Degradation rate [/h]")  
    if isinstance(save_dir, str):
        plt.savefig(save_dir.replace(".png", "_rt.png"))
    #
    if pop:
        plt.show()
    #
    plt.clf()
    plt.cla()
    plt.close("all")  



#

if __name__ == "__main__":
    ### --- main script
    # para      - parameter container 
    # res_list  - list for all results. 
    y0 = [0 for i in range(4)]
    res_list = []
    for i in range(10):
        ini_temp = []
        for j in range(4):
            ini_temp.append(rd.uniform(0,1))
        #
        
        total_concentration = rd.uniform(0,X(0))
        y0 = []
        for j in range(4):
            y0.append(total_concentration * ini_temp[j] / sum(ini_temp))
        res = solve_ode(y0 = y0)
        res_list.append(res)
    # 

    draw_different_intial(res_list, length = 10, num_period = 1, pop = True, save_dir = False)
#
